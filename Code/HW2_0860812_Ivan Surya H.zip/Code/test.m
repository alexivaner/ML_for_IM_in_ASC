for i=7:12
disp(i)
end
