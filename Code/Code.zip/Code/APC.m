  function [uex_center_intuitive] = APC(ue_num, bs_num, RSRP_signal, RSRP_interference)
 
   %RSRP_signal(RSRP_signal~=0)=1 ; %�A�ȰT�����令1��index
   service_UE = RSRP_signal;
   service_UE(service_UE~=0)=1 ; %�A�ȰT�����令1��index
   
  % APC_select_cell
    % Similarity Matrix
    %service_UE = zeros(ue_num,bs_num);
    MI = zeros(ue_num,bs_num);
    MI_total = zeros(bs_num,bs_num);
    for ii = 1 : bs_num
        for jj = 1 : bs_num
            %service_UE = RSRP_signal;
            MI(:,jj) = service_UE(:,ii).*RSRP_interference(:,jj);
            MI_total(ii,jj) = sum(MI(:,jj));
            %MI_total(ii,jj) = sum(MI(:,jj))*(sum(RSRP_signal(:,jj))/(sum(RSRP_signal(:,jj))+10^(-18))); 
            %MI_total(ii,jj) = sum(MI(:,jj))/(sum(RSRP_signal(:,jj))+10^(-18));  
            if MI_total(ii,jj) == 0 
                MI_total(ii,jj) = 1; 
            end
        end
    end
    min_MI = min(min(MI_total).');

    Pref = zeros(bs_num,1);
    for hh = 1 : bs_num
        Pref(hh,1) = mean(sum(MI_total(hh,:))-1);
    end
    Pref_avg = mean(Pref.');

    for ii = 1 : bs_num
        if MI_total(ii,ii) == 1 
            MI_total(ii,ii) = min_MI;
        end
    end

    % Responsibility Matrix
    Av = zeros(bs_num,bs_num); %�s�W1060627

    dd=1;
    for ddd = 1 :  dd %�s�W1060627
        Respon = zeros(bs_num,bs_num);
        QQ = [];
        for ii = 1 : bs_num
            for jj = 1 : bs_num
                Re_Ob = MI_total(ii,jj);
                cccc = 1 : bs_num;
                %Respon(ii,jj) = Re_Ob - max(MI_total(ii,MI_total(ii,:)~=Re_Ob));
                QQ(ii,:) = Av(ii,find(cccc~=jj)) + MI_total(ii,find(cccc~=jj));
                Respon(ii,jj) = Re_Ob - max(QQ(ii,:)); %�s�W1060627
            end
        end 

        % Availability Matrix
        Undiagonal = zeros(bs_num-1,1);
        Av = zeros(bs_num,bs_num);
        Undiagonal_Re = zeros(bs_num-2,1);
        for ii = 1 : bs_num
            Diagonal = Respon(ii,ii);
            aaaa = 1 : bs_num;
            Undiagonal = Respon(find(aaaa~=ii),ii);
            Undiagonal_add_Dia = 0;
            for jj = 1 : bs_num-1
                if Undiagonal(jj,1) > 0
                    Undiagonal_add_Dia = Undiagonal_add_Dia + Undiagonal(jj,1);
                end
            end
            Av(ii,ii) = Undiagonal_add_Dia;

            for hh = 1 : bs_num-1
                %Undiagonal_Ob = Undiagonal(hh,1);
                bbbb = 1 : (bs_num-1);
                Undiagonal_Re = Undiagonal(find(bbbb~=hh),1);
                Undiagonal_add_Undia = 0;
                for gg = 1 : bs_num-2
                    if Undiagonal_Re(gg,1) > 0
                        Undiagonal_add_Undia = Undiagonal_add_Undia + Undiagonal_Re(gg,1);
                    end
                end
                if hh >= ii
                    Av(hh+1,ii) = Undiagonal_add_Undia + Diagonal;
                else
                    Av(hh,ii) = Undiagonal_add_Undia + Diagonal;
                end
            end 
        end

        %Criterion Matrix
        Cri = zeros(bs_num,bs_num);
        exemplar = zeros(bs_num,1);
        uex_index = zeros(bs_num,bs_num);
        Cri = Respon + Av;
        for ii = 1 : bs_num
            exemplar(ii,1) = max(Cri(ii,:));
            uex_index(ii,:) = Cri(ii,:)==exemplar(ii,1);
        end

        %Interference
        %��X���s�ߪ�cell
        j=0;
        uex_center_intuitive = [];
        for i = 1 : bs_num
            a = sum(uex_index(:,i));
            if a >= 2
                j=j+1;   
                uex_center_intuitive(1,j)=i;
                %ex_center(g,j)=i;
            end
        end  

         %��X���s�ߪ�cell - ��W�@�Ӥ]���s�� for FFR cluster
        j=0;
        %uex_center_cluster = [];
        for i = 1 : bs_num
            a = sum(uex_index(:,i));
            if a >= 1
                j=j+1;   
                uex_center_cluster(1,j)=i;
                %uex_center_cluster(g,j)=i;
            end
        end  
        
        
    end